<?php
/**
 * @package		StMarsh
 * @subpackage	mod_articles_all
 * @copyright	(C) 2013 StMarsh
 * @license		GNU General Public License
 */

defined('_JEXEC') or die;

require_once JPATH_SITE.'/components/com_content/helpers/route.php';

JModelLegacy::addIncludePath(JPATH_SITE.'/components/com_content/models', 'ContentModel');

Class modArticlesAllHelper
{
	function getList(&$params)
    {
        $db = JFactory::getDbo();
        $Cat = $params->get("catlist");
        $Count = $params->get("countcat");
        if ($Cat==null){
            $query = "SELECT id,title FROM #__content LIMIT $Count";
        }
        else {
            $query = "SELECT id,title FROM #__content WHERE catid=$Cat LIMIT $Count";
        }
        $db->setQuery($query);
        $list = $db->loadObjectList();

        // Возвращаем массив заголовков
        return $list;
    }
}

?>