<?php
/**
 * @package		StMarsh
 * @subpackage	mod_articles_slideshow
 * @copyright	(C) 2013 StMarsh
 * @license		GNU General Public License
 */

// no direct access
defined('_JEXEC') or die;
$Color = $params->get("titlecolor");
$doc = & JFactory::getDocument();
$doc->addStyleSheet(JURI::root(true) . "/modules/mod_articles_slideshow/style.css");

?>

<div class="cont">
    <input type="radio" name="slides" id="slide1" checked>
    <input type="radio" name="slides" id="slide2">
    <input type="radio" name="slides" id="slide3">
    <input type="radio" name="slides" id="slide4">
    <input type="radio" name="slides" id="slide5">

    <div class="slider">
        <?php $i = 1; foreach ($list as $item) :  ?>
            <div class="block b<?php echo $i; $i++; ?>">
                <img alt="" src="modules/mod_articles_slideshow/GirlsW.jpg" />
                <a href="index.php/component/content/article/2-uncategorised/<?php echo $item->id; ?>" style="color: <?php echo $Color; ?>"><?php echo $item->title; ?></a>
                <?php echo $item->introtext; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="side-controls">
        <label for="slide1"></label>
        <label for="slide2"></label>
        <label for="slide3"></label>
        <label for="slide4"></label>
        <label for="slide5"></label>
    </div>
    <div class="controls">
        <label for="slide1"></label>
        <label for="slide2"></label>
        <label for="slide3"></label>
        <label for="slide4"></label>
        <label for="slide5"></label>
    </div>
</div>