<?php
/**
 * @package		StMarsh
 * @subpackage	mod_articles_slideshow
 * @copyright	(C) 2013 StMarsh
 * @license		GNU General Public License
 */

defined('_JEXEC') or die;

require_once JPATH_SITE.'/components/com_content/helpers/route.php';

JModelLegacy::addIncludePath(JPATH_SITE.'/components/com_content/models', 'ContentModel');

Class modArticlesSlideshowHelper
{
	function getList(&$params)
    {
        $db = JFactory::getDbo();
        $query = "SELECT id,title,introtext,images FROM #__content LIMIT 5";
        $db->setQuery($query);
        $list = $db->loadObjectList();

        // Возвращаем массив заголовков
        return $list;
    }
}

?>