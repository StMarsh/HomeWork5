<?php
/**
 * @package		StMarsh
 * @subpackage	mod_articles_slideshow
 * @copyright	(C) 2013 StMarsh
 * @license		GNU General Public License
 */

defined('_JEXEC') or die;

require_once dirname(__FILE__).'/helper.php';

$list = modArticlesSlideshowHelper::getList($params);

require JModuleHelper::getLayoutPath('mod_articles_slideshow', $params->get('layout', 'default'));
